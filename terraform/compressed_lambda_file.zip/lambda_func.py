import boto3
import pandas as pd
from io import BytesIO
import csv
import os
from pprint import pprint

def lambda_handler(json_file):
    s3 = boto3.client("s3")

    """Get CSV file from the storage bucket"""
    response = s3.get_object(
            Bucket="ds-storage-bucket-123", Key="people_data.csv"
        )
    
    """Convert the CSV File to a DataFrame"""
    content = response["Body"].read()
    df = pd.read_csv(BytesIO(content))

    """Obfuscate given columns"""
    for i, row in df.iterrows():
        for column_name in json_file["pii_fields"]:
            df.at[i, column_name] = '***'

    """Create new CSV file from DataFrame"""
    df.to_csv("obfuscated_people_data.csv", index=False)

    """Upload new CSV file to the target bucket"""
    s3.upload_file(
            "obfuscated_people_data.csv",
            "ds-target-bucket-123",
            "obfuscated_people_data.csv"
        )
    
    """Remove new CSV file from the local repository"""
    os.remove("obfuscated_people_data.csv")

    return {}
